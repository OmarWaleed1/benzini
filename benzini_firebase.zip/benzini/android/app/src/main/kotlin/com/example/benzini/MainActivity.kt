package com.example.benzini

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
