// Generated from google-services.json for project banzeny-72743
import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      throw UnsupportedError('Web platform not configured for this app.');
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  // From google-services.json — project: banzeny-72743
  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyD-rKTFPzxdgXILXJWNtFmzBSGb7UsjPtA',
    appId: '1:279200883611:android:d0a4c09a22d1d70be4f73e',
    messagingSenderId: '279200883611',
    projectId: 'banzeny-72743',
    databaseURL: 'https://banzeny-72743-default-rtdb.firebaseio.com',
    storageBucket: 'banzeny-72743.firebasestorage.app',
  );

  // iOS — add GoogleService-Info.plist later if needed
  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyD-rKTFPzxdgXILXJWNtFmzBSGb7UsjPtA',
    appId: '1:279200883611:ios:placeholder',
    messagingSenderId: '279200883611',
    projectId: 'banzeny-72743',
    databaseURL: 'https://banzeny-72743-default-rtdb.firebaseio.com',
    storageBucket: 'banzeny-72743.firebasestorage.app',
    iosBundleId: 'com.example.benzini',
  );
}
