import 'dart:math';

enum FuelType { regular, premium, both, unknown }
enum CrowdLevel { none, low, medium, high, unknown }
enum StationStatus { open, closed, unknown }

class FuelReport {
  final String id;
  final String stationId;
  final String userId;
  final String userDisplayName;
  final FuelType fuelType;
  final CrowdLevel crowdLevel;
  final StationStatus status;
  final double? price;
  final String? note;
  final DateTime reportedAt;
  int upvotes;
  int downvotes;
  bool isExpired;

  FuelReport({
    required this.id,
    required this.stationId,
    required this.userId,
    this.userDisplayName = 'مجهول',
    required this.fuelType,
    required this.crowdLevel,
    required this.status,
    this.price,
    this.note,
    required this.reportedAt,
    this.upvotes = 0,
    this.downvotes = 0,
    this.isExpired = false,
  }) {
    // تقارير أقدم من ساعتين تصبح منتهية
    isExpired = DateTime.now().difference(reportedAt).inHours >= 2;
  }

  bool get isFresh => !isExpired;

  Map<String, dynamic> toJson() => {
        'id': id,
        'stationId': stationId,
        'userId': userId,
        'userDisplayName': userDisplayName,
        'fuelType': fuelType.index,
        'crowdLevel': crowdLevel.index,
        'status': status.index,
        'price': price,
        'note': note,
        'reportedAt': reportedAt.toIso8601String(),
        'upvotes': upvotes,
        'downvotes': downvotes,
      };

  factory FuelReport.fromJson(Map<String, dynamic> j) => FuelReport(
        id: j['id'] ?? '',
        stationId: j['stationId'] ?? '',
        userId: j['userId'] ?? '',
        userDisplayName: j['userDisplayName'] ?? 'مجهول',
        fuelType: FuelType.values[j['fuelType'] ?? 3],
        crowdLevel: CrowdLevel.values[j['crowdLevel'] ?? 4],
        status: StationStatus.values[j['status'] ?? 2],
        price: (j['price'] as num?)?.toDouble(),
        note: j['note'],
        reportedAt: j['reportedAt'] != null
            ? DateTime.parse(j['reportedAt'])
            : DateTime.now(),
        upvotes: j['upvotes'] ?? 0,
        downvotes: j['downvotes'] ?? 0,
      );

  factory FuelReport.fromFirebase(Map<dynamic, dynamic> j) =>
      FuelReport.fromJson(Map<String, dynamic>.from(j));
}

class AppUser {
  final String uid;
  final String displayName;
  final String phone;
  int points;
  int reportsCount;
  List<String> subscribedStations;

  AppUser({
    required this.uid,
    required this.displayName,
    required this.phone,
    this.points = 0,
    this.reportsCount = 0,
    this.subscribedStations = const [],
  });

  String get rank {
    if (points >= 500) return '🥇 خبير';
    if (points >= 200) return '🥈 محترف';
    if (points >= 50) return '🥉 نشيط';
    return '🌱 جديد';
  }

  Map<String, dynamic> toJson() => {
        'uid': uid,
        'displayName': displayName,
        'phone': phone,
        'points': points,
        'reportsCount': reportsCount,
        'subscribedStations': subscribedStations,
      };

  factory AppUser.fromJson(Map<String, dynamic> j) => AppUser(
        uid: j['uid'] ?? '',
        displayName: j['displayName'] ?? 'مستخدم',
        phone: j['phone'] ?? '',
        points: j['points'] ?? 0,
        reportsCount: j['reportsCount'] ?? 0,
        subscribedStations: List<String>.from(j['subscribedStations'] ?? []),
      );

  factory AppUser.fromFirebase(Map<dynamic, dynamic> j) =>
      AppUser.fromJson(Map<String, dynamic>.from(j));
}

class Station {
  final String id;
  final String name;
  final String address;
  final String city;
  final double lat;
  final double lng;
  final String addedBy;
  List<FuelReport> reports;

  Station({
    required this.id,
    required this.name,
    required this.address,
    this.city = 'بغداد',
    required this.lat,
    required this.lng,
    this.addedBy = '',
    this.reports = const [],
  });

  FuelReport? get latestReport {
    if (reports.isEmpty) return null;
    final fresh = reports.where((r) => r.isFresh).toList();
    if (fresh.isNotEmpty) {
      return fresh.reduce((a, b) => a.reportedAt.isAfter(b.reportedAt) ? a : b);
    }
    return reports.reduce((a, b) => a.reportedAt.isAfter(b.reportedAt) ? a : b);
  }

  StationStatus get currentStatus => latestReport?.status ?? StationStatus.unknown;
  FuelType get currentFuelType => latestReport?.fuelType ?? FuelType.unknown;
  CrowdLevel get currentCrowdLevel => latestReport?.crowdLevel ?? CrowdLevel.unknown;
  bool get hasStaleData => latestReport?.isExpired ?? false;

  String get estimatedWaitTime {
    switch (currentCrowdLevel) {
      case CrowdLevel.none: return 'بدون انتظار';
      case CrowdLevel.low: return '~10 دقائق';
      case CrowdLevel.medium: return '~25 دقيقة';
      case CrowdLevel.high: return '~60 دقيقة أو أكثر';
      default: return 'غير معروف';
    }
  }

  double distanceTo(double userLat, double userLng) {
    const R = 6371.0;
    final dLat = (lat - userLat) * pi / 180;
    final dLng = (lng - userLng) * pi / 180;
    final a = sin(dLat / 2) * sin(dLat / 2) +
        cos(userLat * pi / 180) * cos(lat * pi / 180) * sin(dLng / 2) * sin(dLng / 2);
    return R * 2 * atan2(sqrt(a), sqrt(1 - a));
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'address': address,
        'city': city,
        'lat': lat,
        'lng': lng,
        'addedBy': addedBy,
      };

  factory Station.fromJson(Map<String, dynamic> j) => Station(
        id: j['id'] ?? '',
        name: j['name'] ?? '',
        address: j['address'] ?? '',
        city: j['city'] ?? 'بغداد',
        lat: (j['lat'] as num?)?.toDouble() ?? 0,
        lng: (j['lng'] as num?)?.toDouble() ?? 0,
        addedBy: j['addedBy'] ?? '',
      );

  factory Station.fromFirebase(String id, Map<dynamic, dynamic> j) =>
      Station.fromJson({...Map<String, dynamic>.from(j), 'id': id});
}
