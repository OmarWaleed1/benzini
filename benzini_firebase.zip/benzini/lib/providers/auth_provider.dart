import 'package:flutter/material.dart';
import '../models/station.dart';
import '../services/firebase_service.dart';

enum AuthState { unknown, unauthenticated, authenticated }

class AppAuthProvider extends ChangeNotifier {
  final _svc = FirebaseService();
  AuthState _state = AuthState.unknown;
  AppUser? _user;
  String? _verificationId;
  bool _loading = false;
  String? _error;

  AuthState get state => _state;
  AppUser? get user => _user;
  bool get loading => _loading;
  String? get error => _error;
  bool get isLoggedIn => _state == AuthState.authenticated;

  Future<void> init() async {
    if (_svc.isLoggedIn) {
      final uid = _svc.currentUser!.uid;
      _user = await _svc.getUser(uid);
      if (_user == null) {
        // User exists in auth but not in DB — shouldn't happen normally
        _state = AuthState.unauthenticated;
      } else {
        _state = AuthState.authenticated;
      }
    } else {
      _state = AuthState.unauthenticated;
    }
    notifyListeners();
  }

  Future<void> sendOtp(String phone) async {
    _loading = true;
    _error = null;
    notifyListeners();
    await _svc.verifyPhone(
      phoneNumber: phone,
      onCodeSent: (id) {
        _verificationId = id;
        _loading = false;
        notifyListeners();
      },
      onError: (e) {
        _error = e;
        _loading = false;
        notifyListeners();
      },
    );
  }

  Future<bool> verifyOtp(String code, String displayName) async {
    if (_verificationId == null) return false;
    _loading = true;
    _error = null;
    notifyListeners();
    try {
      final cred = await _svc.signInWithPhone(_verificationId!, code);
      final uid = cred.user!.uid;
      // Check if user exists
      var user = await _svc.getUser(uid);
      if (user == null) {
        user = AppUser(
          uid: uid,
          displayName: displayName,
          phone: cred.user!.phoneNumber ?? '',
        );
        await _svc.saveUser(user);
      }
      _user = user;
      _state = AuthState.authenticated;
      _loading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _error = 'كود خاطئ، حاول مرة أخرى';
      _loading = false;
      notifyListeners();
      return false;
    }
  }

  Future<void> signOut() async {
    await _svc.signOut();
    _user = null;
    _state = AuthState.unauthenticated;
    notifyListeners();
  }

  Future<void> refreshUser() async {
    if (_user != null) {
      _user = await _svc.getUser(_user!.uid);
      notifyListeners();
    }
  }
}
