import 'dart:async';
import 'package:flutter/material.dart';
import '../models/station.dart';
import '../services/firebase_service.dart';

class StationsProvider extends ChangeNotifier {
  final _svc = FirebaseService();

  List<Station> _stations = [];
  Map<String, List<FuelReport>> _reportsCache = {};
  StreamSubscription? _stationsSub;
  Map<String, StreamSubscription> _reportsSubs = {};

  double? _userLat;
  double? _userLng;
  String _filter = 'all';
  String _cityFilter = 'all';
  bool _loading = true;

  List<Station> get stations => _filteredStations;
  bool get loading => _loading;
  String get filter => _filter;
  String get cityFilter => _cityFilter;
  double? get userLat => _userLat;
  double? get userLng => _userLng;

  List<String> get cities {
    final set = _stations.map((s) => s.city).toSet().toList();
    set.sort();
    return ['all', ...set];
  }

  List<Station> get _filteredStations {
    var list = _stations.map((s) {
      final reports = _reportsCache[s.id] ?? [];
      return Station(
        id: s.id, name: s.name, address: s.address,
        city: s.city, lat: s.lat, lng: s.lng, addedBy: s.addedBy,
        reports: reports,
      );
    }).toList();

    if (_cityFilter != 'all') {
      list = list.where((s) => s.city == _cityFilter).toList();
    }
    if (_filter == 'open') {
      list = list.where((s) => s.currentStatus == StationStatus.open).toList();
    } else if (_filter == 'premium') {
      list = list.where((s) => s.currentFuelType == FuelType.premium || s.currentFuelType == FuelType.both).toList();
    } else if (_filter == 'regular') {
      list = list.where((s) => s.currentFuelType == FuelType.regular || s.currentFuelType == FuelType.both).toList();
    }
    if (_userLat != null && _userLng != null) {
      list.sort((a, b) => a.distanceTo(_userLat!, _userLng!).compareTo(b.distanceTo(_userLat!, _userLng!)));
    }
    return list;
  }

  void setFilter(String f) { _filter = f; notifyListeners(); }
  void setCityFilter(String c) { _cityFilter = c; notifyListeners(); }
  void setUserLocation(double lat, double lng) { _userLat = lat; _userLng = lng; notifyListeners(); }

  Future<void> init() async {
    _loading = true;
    notifyListeners();

    _stationsSub = _svc.stationsStream().listen((stations) {
      _stations = stations;
      _loading = false;
      notifyListeners();
      // Subscribe to reports for each station
      for (final s in stations) {
        if (!_reportsSubs.containsKey(s.id)) {
          _reportsSubs[s.id] = _svc.reportsStream(s.id).listen((reports) {
            _reportsCache[s.id] = reports;
            notifyListeners();
          });
        }
      }
    });
  }

  Station? getStation(String id) {
    try {
      final s = _stations.firstWhere((s) => s.id == id);
      return Station(
        id: s.id, name: s.name, address: s.address,
        city: s.city, lat: s.lat, lng: s.lng, addedBy: s.addedBy,
        reports: _reportsCache[s.id] ?? [],
      );
    } catch (_) { return null; }
  }

  Future<void> addReport(FuelReport report) async {
    await _svc.addReport(report);
  }

  Future<void> voteReport(String stationId, String reportId, bool upvote) async {
    await _svc.voteReport(stationId, reportId, upvote);
  }

  Future<void> addStation(Station station) async {
    await _svc.addStation(station);
  }

  Future<bool> isSubscribed(String userId, String stationId) =>
      _svc.isSubscribed(userId, stationId);

  Future<void> toggleSubscription(String userId, String stationId, bool subscribe) async {
    if (subscribe) {
      await _svc.subscribeToStation(userId, stationId);
    } else {
      await _svc.unsubscribeFromStation(userId, stationId);
    }
  }

  @override
  void dispose() {
    _stationsSub?.cancel();
    for (final sub in _reportsSubs.values) { sub.cancel(); }
    super.dispose();
  }
}
