import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';
import '../models/station.dart';
import '../providers/stations_provider.dart';
import '../theme.dart';

class AddStationScreen extends StatefulWidget {
  const AddStationScreen({super.key});
  @override
  State<AddStationScreen> createState() => _AddStationScreenState();
}

class _AddStationScreenState extends State<AddStationScreen> {
  final _nameCtrl = TextEditingController();
  final _addressCtrl = TextEditingController();
  final _mapController = MapController();
  LatLng _selectedPos = const LatLng(33.3152, 44.3661);
  String _selectedCity = 'بغداد';
  bool _submitting = false;

  final _cities = ['بغداد', 'الفلوجة', 'الرمادي', 'الموصل', 'البصرة', 'أربيل', 'كركوك', 'النجف', 'كربلاء', 'الناصرية', 'العمارة', 'الديوانية', 'بابل', 'سامراء', 'تكريت'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إضافة محطة جديدة')),
      body: Column(
        children: [
          // Map picker
          SizedBox(
            height: 260,
            child: Stack(
              children: [
                FlutterMap(
                  mapController: _mapController,
                  options: MapOptions(
                    initialCenter: _selectedPos,
                    initialZoom: 13,
                    onTap: (_, point) => setState(() => _selectedPos = point),
                  ),
                  children: [
                    TileLayer(urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', userAgentPackageName: 'com.example.benzini'),
                    MarkerLayer(markers: [
                      Marker(
                        point: _selectedPos,
                        width: 50, height: 60,
                        child: const Column(
                          children: [
                            Icon(Icons.location_pin, color: AppTheme.closedRed, size: 40),
                          ],
                        ),
                      ),
                    ]),
                  ],
                ),
                Positioned(
                  top: 12, right: 12,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(color: Colors.white.withOpacity(0.9), borderRadius: BorderRadius.circular(8)),
                    child: const Text('اضغط على الخريطة لتحديد الموقع', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                  ),
                ),
              ],
            ),
          ),
          const Divider(height: 1),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('الموقع المحدد', style: TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
                  const SizedBox(height: 4),
                  Text(
                    '${_selectedPos.latitude.toStringAsFixed(5)}, ${_selectedPos.longitude.toStringAsFixed(5)}',
                    style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppTheme.primary, fontFamily: 'monospace'),
                  ),
                  const SizedBox(height: 20),
                  TextField(
                    controller: _nameCtrl,
                    textAlign: TextAlign.right,
                    decoration: const InputDecoration(labelText: 'اسم المحطة *', hintText: 'مثال: محطة الكرادة المركزية'),
                  ),
                  const SizedBox(height: 14),
                  TextField(
                    controller: _addressCtrl,
                    textAlign: TextAlign.right,
                    decoration: const InputDecoration(labelText: 'العنوان *', hintText: 'مثال: شارع الكرادة، بغداد'),
                  ),
                  const SizedBox(height: 14),
                  DropdownButtonFormField<String>(
                    value: _selectedCity,
                    decoration: const InputDecoration(labelText: 'المدينة'),
                    items: _cities.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
                    onChanged: (v) => setState(() => _selectedCity = v!),
                  ),
                  const SizedBox(height: 28),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: _submitting ? null : _submit,
                      icon: const Icon(Icons.add_location_alt),
                      label: _submitting
                          ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                          : const Text('إضافة المحطة'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _submit() async {
    if (_nameCtrl.text.trim().isEmpty || _addressCtrl.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('الرجاء ملء جميع الحقول')));
      return;
    }
    setState(() => _submitting = true);
    final station = Station(
      id: const Uuid().v4(),
      name: _nameCtrl.text.trim(),
      address: _addressCtrl.text.trim(),
      city: _selectedCity,
      lat: _selectedPos.latitude,
      lng: _selectedPos.longitude,
    );
    await context.read<StationsProvider>().addStation(station);
    if (mounted) {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تمت إضافة المحطة! شكراً 🙏'), backgroundColor: AppTheme.openGreen, behavior: SnackBarBehavior.floating),
      );
    }
  }
}
