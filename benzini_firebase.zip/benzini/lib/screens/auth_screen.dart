import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../theme.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final _phoneCtrl = TextEditingController(text: '+964');
  final _codeCtrl = TextEditingController();
  final _nameCtrl = TextEditingController();
  bool _codeSent = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.surface,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(28),
          child: Consumer<AppAuthProvider>(
            builder: (ctx, auth, _) => Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const SizedBox(height: 40),
                // Logo
                Container(
                  width: 100, height: 100,
                  decoration: BoxDecoration(
                    color: AppTheme.primary,
                    shape: BoxShape.circle,
                    boxShadow: [BoxShadow(color: AppTheme.primary.withOpacity(0.3), blurRadius: 20, spreadRadius: 4)],
                  ),
                  child: const Icon(Icons.local_gas_station, color: Colors.white, size: 54),
                ),
                const SizedBox(height: 24),
                const Text('بنزيني', style: TextStyle(fontSize: 36, fontWeight: FontWeight.w800, color: AppTheme.primary)),
                const SizedBox(height: 8),
                const Text('ساعد مجتمعك — أبلغ عن محطات الوقود', style: TextStyle(fontSize: 15, color: AppTheme.textSecondary), textAlign: TextAlign.center),
                const SizedBox(height: 48),

                if (!_codeSent) ...[
                  // Name field
                  TextField(
                    controller: _nameCtrl,
                    textAlign: TextAlign.right,
                    decoration: const InputDecoration(
                      labelText: 'اسمك',
                      prefixIcon: Icon(Icons.person_outline),
                      hintText: 'مثال: أحمد محمد',
                    ),
                  ),
                  const SizedBox(height: 16),
                  // Phone field
                  TextField(
                    controller: _phoneCtrl,
                    keyboardType: TextInputType.phone,
                    textDirection: TextDirection.ltr,
                    decoration: const InputDecoration(
                      labelText: 'رقم الهاتف',
                      prefixIcon: Icon(Icons.phone_outlined),
                      hintText: '+9647XXXXXXXX',
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text('سيتم إرسال رمز تحقق عبر SMS', style: TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
                  const SizedBox(height: 24),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: auth.loading ? null : _sendOtp,
                      child: auth.loading
                          ? const SizedBox(height: 22, width: 22, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                          : const Text('إرسال الرمز'),
                    ),
                  ),
                ] else ...[
                  // OTP field
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: AppTheme.primary.withOpacity(0.06),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: AppTheme.primary.withOpacity(0.2)),
                    ),
                    child: Column(
                      children: [
                        const Icon(Icons.sms_outlined, color: AppTheme.primary, size: 36),
                        const SizedBox(height: 8),
                        Text('أُرسل رمز التحقق إلى\n${_phoneCtrl.text}', textAlign: TextAlign.center, style: const TextStyle(color: AppTheme.textSecondary)),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                  TextField(
                    controller: _codeCtrl,
                    keyboardType: TextInputType.number,
                    textAlign: TextAlign.center,
                    maxLength: 6,
                    style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800, letterSpacing: 8),
                    decoration: const InputDecoration(counterText: '', labelText: 'رمز التحقق'),
                  ),
                  const SizedBox(height: 24),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: auth.loading ? null : _verifyOtp,
                      child: auth.loading
                          ? const SizedBox(height: 22, width: 22, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                          : const Text('تأكيد الدخول'),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextButton(
                    onPressed: () => setState(() { _codeSent = false; }),
                    child: const Text('تغيير الرقم', style: TextStyle(color: AppTheme.textSecondary)),
                  ),
                ],

                if (auth.error != null) ...[
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(color: AppTheme.closedRed.withOpacity(0.08), borderRadius: BorderRadius.circular(10)),
                    child: Row(
                      children: [
                        const Icon(Icons.error_outline, color: AppTheme.closedRed, size: 18),
                        const SizedBox(width: 8),
                        Expanded(child: Text(auth.error!, style: const TextStyle(color: AppTheme.closedRed, fontSize: 13))),
                      ],
                    ),
                  ),
                ],

                const SizedBox(height: 40),
                // Guest note
                TextButton(
                  onPressed: () {},
                  child: const Text('متابعة كضيف (عرض فقط)', style: TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _sendOtp() {
    if (_nameCtrl.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('الرجاء إدخال اسمك')));
      return;
    }
    if (_phoneCtrl.text.length < 10) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('رقم الهاتف غير صحيح')));
      return;
    }
    context.read<AppAuthProvider>().sendOtp(_phoneCtrl.text).then((_) {
      setState(() => _codeSent = true);
    });
  }

  void _verifyOtp() async {
    if (_codeCtrl.text.length != 6) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('الرمز يجب أن يكون 6 أرقام')));
      return;
    }
    final ok = await context.read<AppAuthProvider>().verifyOtp(_codeCtrl.text, _nameCtrl.text.trim());
    if (!ok && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('رمز خاطئ'), backgroundColor: AppTheme.closedRed));
    }
  }
}
