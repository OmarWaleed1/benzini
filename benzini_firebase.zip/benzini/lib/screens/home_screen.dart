import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:provider/provider.dart';
import '../models/station.dart';
import '../providers/stations_provider.dart';
import '../providers/auth_provider.dart';
import '../widgets/station_card.dart';
import '../screens/station_detail_screen.dart';
import '../screens/add_station_screen.dart';
import '../screens/profile_screen.dart';
import '../screens/auth_screen.dart';
import '../theme.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final MapController _mapController = MapController();
  int _navIndex = 0;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<StationsProvider>().init();
    });
  }

  @override
  void dispose() { _tabController.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _navIndex == 0
          ? AppBar(
              title: const Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.local_gas_station, color: Colors.white, size: 24),
                SizedBox(width: 8),
                Text('بنزيني'),
              ]),
              actions: [
                Consumer<StationsProvider>(
                  builder: (ctx, provider, _) => PopupMenuButton<String>(
                    icon: const Icon(Icons.filter_list, color: Colors.white),
                    tooltip: 'تصفية حسب المدينة',
                    onSelected: (city) => provider.setCityFilter(city),
                    itemBuilder: (_) => provider.cities.map((c) => PopupMenuItem(
                      value: c,
                      child: Text(c == 'all' ? '🗺️ جميع المدن' : c),
                    )).toList(),
                  ),
                ),
              ],
              bottom: TabBar(
                controller: _tabController,
                indicatorColor: AppTheme.accent,
                labelColor: Colors.white,
                unselectedLabelColor: Colors.white60,
                labelStyle: const TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.w700, fontSize: 14),
                tabs: const [
                  Tab(icon: Icon(Icons.map_outlined), text: 'الخريطة'),
                  Tab(icon: Icon(Icons.list_alt), text: 'القائمة'),
                ],
              ),
            )
          : null,
      body: IndexedStack(
        index: _navIndex,
        children: [
          // Main feed
          Column(
            children: [
              _FilterBar(),
              _StatsBar(),
              Expanded(
                child: TabBarView(
                  controller: _tabController,
                  children: [
                    _MapTab(mapController: _mapController),
                    _ListTab(),
                  ],
                ),
              ),
            ],
          ),
          // Profile
          Consumer<AppAuthProvider>(
            builder: (ctx, auth, _) => auth.isLoggedIn ? const ProfileScreen() : const AuthScreen(),
          ),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _navIndex,
        onDestinationSelected: (i) => setState(() => _navIndex = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.local_gas_station_outlined), selectedIcon: Icon(Icons.local_gas_station), label: 'المحطات'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'حسابي'),
        ],
      ),
      floatingActionButton: _navIndex == 0
          ? FloatingActionButton(
              onPressed: () {
                final auth = context.read<AppAuthProvider>();
                if (!auth.isLoggedIn) {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('سجّل دخولك لإضافة محطة جديدة')));
                  return;
                }
                Navigator.push(context, MaterialPageRoute(builder: (_) => MultiProvider(
                  providers: [ChangeNotifierProvider.value(value: context.read<StationsProvider>())],
                  child: const AddStationScreen(),
                )));
              },
              backgroundColor: AppTheme.accent,
              child: const Icon(Icons.add_location_alt, color: Colors.white),
            )
          : null,
    );
  }
}

class _FilterBar extends StatelessWidget {
  final filters = const [('all', '🔍 الكل'), ('open', '✅ مفتوحة'), ('premium', '⭐ محسن'), ('regular', '⛽ عادي')];
  @override
  Widget build(BuildContext context) {
    return Consumer<StationsProvider>(
      builder: (ctx, provider, _) => Container(
        height: 50, color: Colors.white,
        child: ListView.builder(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          itemCount: filters.length,
          itemBuilder: (ctx, i) {
            final (key, label) = filters[i];
            final selected = provider.filter == key;
            return Padding(
              padding: const EdgeInsets.only(right: 8),
              child: GestureDetector(
                onTap: () => provider.setFilter(key),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 150),
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                  decoration: BoxDecoration(
                    color: selected ? AppTheme.primary : Colors.transparent,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: selected ? AppTheme.primary : AppTheme.divider),
                  ),
                  child: Text(label, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: selected ? Colors.white : AppTheme.textSecondary, fontFamily: 'Cairo')),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

class _StatsBar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Consumer<StationsProvider>(
      builder: (ctx, provider, _) {
        final all = provider.stations;
        final open = all.where((s) => s.currentStatus == StationStatus.open).length;
        final closed = all.where((s) => s.currentStatus == StationStatus.closed).length;
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          color: AppTheme.surface,
          child: Row(
            children: [
              _S('${all.length}', 'محطة', AppTheme.primary),
              const SizedBox(width: 16),
              _S('$open', 'مفتوحة', AppTheme.openGreen),
              const SizedBox(width: 16),
              _S('$closed', 'مغلقة', AppTheme.closedRed),
              const Spacer(),
              if (provider.cityFilter != 'all')
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(color: AppTheme.accent.withOpacity(0.15), borderRadius: BorderRadius.circular(8)),
                  child: Text(provider.cityFilter, style: const TextStyle(fontSize: 12, color: AppTheme.accent, fontWeight: FontWeight.w700)),
                ),
            ],
          ),
        );
      },
    );
  }
}
class _S extends StatelessWidget {
  final String c, l; final Color col;
  const _S(this.c, this.l, this.col);
  @override Widget build(BuildContext context) => Row(children: [Text(c, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: col)), const SizedBox(width: 4), Text(l, style: const TextStyle(fontSize: 12, color: AppTheme.textSecondary))]);
}

class _MapTab extends StatelessWidget {
  final MapController mapController;
  const _MapTab({required this.mapController});

  Color _color(Station s) {
    if (s.currentStatus == StationStatus.closed) return AppTheme.closedRed;
    if (s.currentStatus == StationStatus.open) return AppTheme.openGreen;
    return AppTheme.unknownGrey;
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<StationsProvider>(
      builder: (ctx, provider, _) => FlutterMap(
        mapController: mapController,
        options: const MapOptions(initialCenter: LatLng(33.3152, 44.3661), initialZoom: 12),
        children: [
          TileLayer(urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', userAgentPackageName: 'com.example.benzini'),
          MarkerLayer(
            markers: provider.stations.map((station) => Marker(
              point: LatLng(station.lat, station.lng),
              width: 50, height: 60,
              child: GestureDetector(
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => MultiProvider(
                  providers: [ChangeNotifierProvider.value(value: provider), ChangeNotifierProvider.value(value: context.read<AppAuthProvider>())],
                  child: StationDetailScreen(stationId: station.id),
                ))),
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(color: _color(station), shape: BoxShape.circle,
                          boxShadow: [BoxShadow(color: _color(station).withOpacity(0.4), blurRadius: 6, spreadRadius: 1)]),
                      child: const Icon(Icons.local_gas_station, color: Colors.white, size: 18),
                    ),
                    Container(
                      constraints: const BoxConstraints(maxWidth: 60),
                      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(4), boxShadow: [const BoxShadow(color: Colors.black12, blurRadius: 3)]),
                      child: Text(station.name.split(' ').take(2).join(' '), style: const TextStyle(fontSize: 8, fontWeight: FontWeight.w700, color: AppTheme.textPrimary), textAlign: TextAlign.center, overflow: TextOverflow.ellipsis),
                    ),
                  ],
                ),
              ),
            )).toList(),
          ),
        ],
      ),
    );
  }
}

class _ListTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Consumer<StationsProvider>(
      builder: (ctx, provider, _) {
        if (provider.loading) return const Center(child: CircularProgressIndicator(color: AppTheme.primary));
        if (provider.stations.isEmpty) return const Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(Icons.local_gas_station_outlined, size: 64, color: AppTheme.unknownGrey),
          SizedBox(height: 12),
          Text('لا توجد محطات', style: TextStyle(color: AppTheme.textSecondary, fontSize: 16)),
        ]));
        return ListView.builder(
          padding: const EdgeInsets.symmetric(vertical: 8),
          itemCount: provider.stations.length,
          itemBuilder: (ctx, i) {
            final station = provider.stations[i];
            final dist = (provider.userLat != null && provider.userLng != null) ? station.distanceTo(provider.userLat!, provider.userLng!) : null;
            return StationCard(
              station: station, distanceKm: dist,
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => MultiProvider(
                providers: [ChangeNotifierProvider.value(value: provider), ChangeNotifierProvider.value(value: context.read<AppAuthProvider>())],
                child: StationDetailScreen(stationId: station.id),
              ))),
            );
          },
        );
      },
    );
  }
}
