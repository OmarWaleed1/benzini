import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../services/firebase_service.dart';
import '../models/station.dart';
import '../theme.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  List<AppUser> _leaderboard = [];
  bool _loadingBoard = true;

  @override
  void initState() {
    super.initState();
    _loadLeaderboard();
  }

  Future<void> _loadLeaderboard() async {
    final list = await FirebaseService().getLeaderboard();
    if (mounted) setState(() { _leaderboard = list; _loadingBoard = false; });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('الملف الشخصي'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () async {
              await context.read<AppAuthProvider>().signOut();
            },
          ),
        ],
      ),
      body: Consumer<AppAuthProvider>(
        builder: (ctx, auth, _) {
          final user = auth.user;
          if (user == null) return const Center(child: CircularProgressIndicator());
          return SingleChildScrollView(
            child: Column(
              children: [
                // Profile header
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(28),
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [AppTheme.primary, AppTheme.primaryLight],
                      begin: Alignment.topRight,
                      end: Alignment.bottomLeft,
                    ),
                  ),
                  child: Column(
                    children: [
                      CircleAvatar(
                        radius: 42,
                        backgroundColor: Colors.white.withOpacity(0.2),
                        child: Text(
                          user.displayName.isNotEmpty ? user.displayName[0] : '؟',
                          style: const TextStyle(fontSize: 36, fontWeight: FontWeight.w800, color: Colors.white),
                        ),
                      ),
                      const SizedBox(height: 12),
                      Text(user.displayName, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: Colors.white)),
                      const SizedBox(height: 4),
                      Text(user.phone, style: TextStyle(fontSize: 14, color: Colors.white.withOpacity(0.8))),
                      const SizedBox(height: 12),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                        decoration: BoxDecoration(
                          color: AppTheme.accent,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(user.rank, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: Colors.white)),
                      ),
                    ],
                  ),
                ),

                // Stats
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      _StatCard('${user.points}', 'نقطة', Icons.star, AppTheme.accent),
                      const SizedBox(width: 12),
                      _StatCard('${user.reportsCount}', 'تقرير', Icons.report_outlined, AppTheme.primary),
                      const SizedBox(width: 12),
                      _StatCard(user.rank.split(' ').first, 'رتبة', Icons.emoji_events_outlined, AppTheme.openGreen),
                    ],
                  ),
                ),

                // Points info
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Row(
                            children: [
                              Icon(Icons.info_outline, color: AppTheme.primary, size: 20),
                              SizedBox(width: 8),
                              Text('كيف تكسب النقاط؟', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                            ],
                          ),
                          const SizedBox(height: 12),
                          _PointRow('إرسال تقرير', '+10 نقاط'),
                          _PointRow('تصويت إيجابي على تقريرك', '+5 نقاط'),
                          _PointRow('إضافة محطة جديدة', '+20 نقطة'),
                          _PointRow('تقرير دقيق (لا تصويت سلبي)', '+5 نقاط إضافية'),
                        ],
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 16),

                // Leaderboard
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Row(
                            children: [
                              Icon(Icons.leaderboard, color: AppTheme.accent, size: 20),
                              SizedBox(width: 8),
                              Text('المتصدرون', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                            ],
                          ),
                          const SizedBox(height: 12),
                          if (_loadingBoard)
                            const Center(child: CircularProgressIndicator())
                          else if (_leaderboard.isEmpty)
                            const Text('لا يوجد بيانات بعد', style: TextStyle(color: AppTheme.textSecondary))
                          else
                            ...List.generate(_leaderboard.length, (i) {
                              final u = _leaderboard[i];
                              final isMe = u.uid == user.uid;
                              return Container(
                                margin: const EdgeInsets.only(bottom: 8),
                                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                decoration: BoxDecoration(
                                  color: isMe ? AppTheme.primary.withOpacity(0.08) : Colors.transparent,
                                  borderRadius: BorderRadius.circular(10),
                                  border: isMe ? Border.all(color: AppTheme.primary.withOpacity(0.3)) : null,
                                ),
                                child: Row(
                                  children: [
                                    Text(
                                      i == 0 ? '🥇' : i == 1 ? '🥈' : i == 2 ? '🥉' : '${i + 1}',
                                      style: const TextStyle(fontSize: 18),
                                    ),
                                    const SizedBox(width: 10),
                                    Expanded(
                                      child: Text(
                                        u.displayName + (isMe ? ' (أنت)' : ''),
                                        style: TextStyle(fontWeight: isMe ? FontWeight.w700 : FontWeight.normal),
                                      ),
                                    ),
                                    Text('${u.points} نقطة', style: const TextStyle(fontWeight: FontWeight.w700, color: AppTheme.accent)),
                                  ],
                                ),
                              );
                            }),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 24),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String value;
  final String label;
  final IconData icon;
  final Color color;
  const _StatCard(this.value, this.label, this.icon, this.color);

  @override
  Widget build(BuildContext context) => Expanded(
        child: Card(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 16),
            child: Column(
              children: [
                Icon(icon, color: color, size: 28),
                const SizedBox(height: 6),
                Text(value, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: color)),
                Text(label, style: const TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
              ],
            ),
          ),
        ),
      );
}

class _PointRow extends StatelessWidget {
  final String action;
  final String points;
  const _PointRow(this.action, this.points);

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 6),
        child: Row(
          children: [
            const Icon(Icons.check_circle_outline, size: 16, color: AppTheme.openGreen),
            const SizedBox(width: 8),
            Expanded(child: Text(action, style: const TextStyle(fontSize: 13))),
            Text(points, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppTheme.accent)),
          ],
        ),
      );
}
