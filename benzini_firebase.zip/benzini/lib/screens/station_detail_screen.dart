import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:timeago/timeago.dart' as timeago;
import '../models/station.dart';
import '../providers/stations_provider.dart';
import '../providers/auth_provider.dart';
import '../widgets/report_sheet.dart';
import '../theme.dart';

class StationDetailScreen extends StatefulWidget {
  final String stationId;
  const StationDetailScreen({super.key, required this.stationId});
  @override
  State<StationDetailScreen> createState() => _StationDetailScreenState();
}

class _StationDetailScreenState extends State<StationDetailScreen> {
  bool _subscribed = false;
  bool _loadingSub = true;

  @override
  void initState() {
    super.initState();
    _checkSubscription();
  }

  Future<void> _checkSubscription() async {
    final auth = context.read<AppAuthProvider>();
    if (!auth.isLoggedIn) { setState(() => _loadingSub = false); return; }
    final sub = await context.read<StationsProvider>().isSubscribed(auth.user!.uid, widget.stationId);
    if (mounted) setState(() { _subscribed = sub; _loadingSub = false; });
  }

  Future<void> _toggleSubscription() async {
    final auth = context.read<AppAuthProvider>();
    if (!auth.isLoggedIn) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('يجب تسجيل الدخول أولاً'))); return; }
    await context.read<StationsProvider>().toggleSubscription(auth.user!.uid, widget.stationId, !_subscribed);
    setState(() => _subscribed = !_subscribed);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(_subscribed ? 'سيتم إشعارك عند تغيير حالة المحطة 🔔' : 'تم إلغاء الاشتراك'),
        backgroundColor: _subscribed ? AppTheme.openGreen : AppTheme.textSecondary,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _shareStation(Station station) {
    final report = station.latestReport;
    final status = station.currentStatus == StationStatus.open ? '✅ مفتوحة' : station.currentStatus == StationStatus.closed ? '🔴 مغلقة' : '❓';
    final fuel = station.currentFuelType == FuelType.regular ? '⛽ وقود عادي' : station.currentFuelType == FuelType.premium ? '⭐ وقود محسن' : station.currentFuelType == FuelType.both ? '⛽⭐ عادي + محسن' : '';
    final crowd = station.currentCrowdLevel == CrowdLevel.none ? '🟢 لا يوجد طابور' : station.currentCrowdLevel == CrowdLevel.low ? '🟡 طابور قصير' : station.currentCrowdLevel == CrowdLevel.medium ? '🟠 طابور متوسط' : station.currentCrowdLevel == CrowdLevel.high ? '🔴 طابور طويل' : '';
    final price = report?.price != null ? '\n💰 السعر: ${report!.price!.toInt()} دينار' : '';

    Share.share(
      '⛽ تحديث من تطبيق بنزيني\n\n📍 ${station.name}\n📌 ${station.address}\n\n$status\n$fuel\n$crowd$price\n\nشارك التطبيق مع أصدقائك!',
      subject: 'حالة ${station.name}',
    );
  }

  @override
  Widget build(BuildContext context) {
    return Consumer2<StationsProvider, AppAuthProvider>(
      builder: (ctx, provider, auth, _) {
        final station = provider.getStation(widget.stationId);
        if (station == null) return const Scaffold(body: Center(child: CircularProgressIndicator()));

        return Scaffold(
          backgroundColor: AppTheme.surface,
          appBar: AppBar(
            title: Text(station.name, overflow: TextOverflow.ellipsis),
            actions: [
              // Share button
              IconButton(
                icon: const Icon(Icons.share_outlined),
                onPressed: () => _shareStation(station),
                tooltip: 'مشاركة',
              ),
              // Subscribe bell
              if (!_loadingSub)
                IconButton(
                  icon: Icon(_subscribed ? Icons.notifications_active : Icons.notifications_none),
                  onPressed: _toggleSubscription,
                  tooltip: _subscribed ? 'إلغاء الإشعارات' : 'تفعيل الإشعارات',
                ),
            ],
          ),
          body: Column(
            children: [
              _StatusHeader(station: station),
              // Wait time estimate
              if (station.currentStatus == StationStatus.open)
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  color: Colors.white,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.timer_outlined, size: 16, color: AppTheme.textSecondary),
                      const SizedBox(width: 6),
                      Text(
                        'وقت الانتظار التقديري: ${station.estimatedWaitTime}',
                        style: const TextStyle(fontSize: 13, color: AppTheme.textSecondary, fontWeight: FontWeight.w600),
                      ),
                    ],
                  ),
                ),
              if (station.hasStaleData)
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(8),
                  color: AppTheme.accent.withOpacity(0.12),
                  child: const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.warning_amber_outlined, size: 16, color: AppTheme.accent),
                      SizedBox(width: 6),
                      Text('آخر تقرير قديم — قد تكون المعلومات غير دقيقة', style: TextStyle(fontSize: 12, color: AppTheme.accent, fontWeight: FontWeight.w600)),
                    ],
                  ),
                ),
              Expanded(
                child: station.reports.isEmpty
                    ? const Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.local_gas_station_outlined, size: 64, color: AppTheme.unknownGrey),
                            SizedBox(height: 12),
                            Text('لا توجد تقارير بعد\nكن أول من يُبلّغ!', textAlign: TextAlign.center, style: TextStyle(color: AppTheme.textSecondary, fontSize: 15)),
                          ],
                        ),
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.all(16),
                        itemCount: station.reports.length,
                        itemBuilder: (ctx, i) => _ReportItem(report: station.reports[i], stationId: widget.stationId),
                      ),
              ),
            ],
          ),
          floatingActionButton: auth.isLoggedIn
              ? FloatingActionButton.extended(
                  onPressed: () => showModalBottomSheet(
                    context: context,
                    isScrollControlled: true,
                    backgroundColor: Colors.transparent,
                    builder: (_) => MultiProvider(
                      providers: [
                        ChangeNotifierProvider.value(value: provider),
                        ChangeNotifierProvider.value(value: auth),
                      ],
                      child: ReportSheet(station: station),
                    ),
                  ),
                  backgroundColor: AppTheme.primary,
                  icon: const Icon(Icons.add, color: Colors.white),
                  label: const Text('إضافة تقرير', style: TextStyle(color: Colors.white, fontFamily: 'Cairo', fontWeight: FontWeight.w700)),
                )
              : FloatingActionButton.extended(
                  onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('سجّل دخولك لإضافة تقارير'))),
                  backgroundColor: AppTheme.textSecondary,
                  icon: const Icon(Icons.lock_outline, color: Colors.white),
                  label: const Text('سجّل دخولك', style: TextStyle(color: Colors.white, fontFamily: 'Cairo')),
                ),
        );
      },
    );
  }
}

class _StatusHeader extends StatelessWidget {
  final Station station;
  const _StatusHeader({required this.station});

  @override
  Widget build(BuildContext context) {
    final status = station.currentStatus;
    final isOpen = status == StationStatus.open;
    final isClosed = status == StationStatus.closed;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: isOpen ? AppTheme.openGreen.withOpacity(0.08) : isClosed ? AppTheme.closedRed.withOpacity(0.08) : Colors.grey.withOpacity(0.06),
        border: const Border(bottom: BorderSide(color: AppTheme.divider)),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(isOpen ? Icons.check_circle : isClosed ? Icons.cancel : Icons.help_outline, color: isOpen ? AppTheme.openGreen : isClosed ? AppTheme.closedRed : AppTheme.unknownGrey, size: 28),
              const SizedBox(width: 8),
              Text(isOpen ? 'المحطة مفتوحة' : isClosed ? 'المحطة مغلقة' : 'الحالة غير معروفة',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: isOpen ? AppTheme.openGreen : isClosed ? AppTheme.closedRed : AppTheme.unknownGrey)),
            ],
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8, runSpacing: 8,
            alignment: WrapAlignment.center,
            children: [
              _chip(Icons.local_gas_station, _fuelLabel(station.currentFuelType), AppTheme.primary),
              _chip(Icons.people, _crowdLabel(station.currentCrowdLevel), crowdColor(station.currentCrowdLevel)),
              if (station.latestReport?.price != null)
                _chip(Icons.payments_outlined, '${station.latestReport!.price!.toInt()} د.ع', AppTheme.accent),
            ],
          ),
        ],
      ),
    );
  }

  Widget _chip(IconData icon, String label, Color color) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(20), border: Border.all(color: color.withOpacity(0.3))),
        child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(icon, size: 16, color: color), const SizedBox(width: 6), Text(label, style: TextStyle(fontSize: 13, color: color, fontWeight: FontWeight.w600))]),
      );

  String _fuelLabel(FuelType f) { switch (f) { case FuelType.regular: return 'وقود عادي'; case FuelType.premium: return 'وقود محسن'; case FuelType.both: return 'عادي + محسن'; default: return 'نوع غير معروف'; } }
  String _crowdLabel(CrowdLevel c) { switch (c) { case CrowdLevel.none: return 'لا طابور'; case CrowdLevel.low: return 'طابور قصير'; case CrowdLevel.medium: return 'طابور متوسط'; case CrowdLevel.high: return 'طابور طويل'; default: return 'الازدحام غير معروف'; } }
}

class _ReportItem extends StatelessWidget {
  final FuelReport report;
  final String stationId;
  const _ReportItem({required this.report, required this.stationId});

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: report.isExpired ? 0.55 : 1.0,
      child: Card(
        margin: const EdgeInsets.only(bottom: 12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  CircleAvatar(
                    radius: 14, backgroundColor: AppTheme.primary.withOpacity(0.12),
                    child: Text(report.userDisplayName.isNotEmpty ? report.userDisplayName[0] : '؟', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppTheme.primary)),
                  ),
                  const SizedBox(width: 8),
                  Text(report.userDisplayName, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                  const Spacer(),
                  if (report.isExpired)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: Colors.grey.withOpacity(0.15), borderRadius: BorderRadius.circular(6)),
                      child: const Text('قديم', style: TextStyle(fontSize: 10, color: AppTheme.textSecondary)),
                    ),
                  const SizedBox(width: 6),
                  Text(timeago.format(report.reportedAt, locale: 'ar'), style: const TextStyle(fontSize: 11, color: AppTheme.textSecondary)),
                ],
              ),
              const SizedBox(height: 10),
              Wrap(
                spacing: 6, runSpacing: 6,
                children: [
                  _tag(report.status == StationStatus.open ? '✅ مفتوحة' : '🔴 مغلقة', report.status == StationStatus.open ? AppTheme.openGreen : AppTheme.closedRed),
                  _tag(_fuelText(report.fuelType), AppTheme.primary),
                  _tag(_crowdText(report.crowdLevel), crowdColor(report.crowdLevel)),
                  if (report.price != null) _tag('${report.price!.toInt()} د.ع', AppTheme.accent),
                ],
              ),
              if (report.note != null && report.note!.isNotEmpty) ...[
                const SizedBox(height: 8),
                Text(report.note!, style: const TextStyle(fontSize: 13, color: AppTheme.textPrimary)),
              ],
              const SizedBox(height: 10),
              Row(
                children: [
                  _VoteBtn(Icons.thumb_up_outlined, report.upvotes, AppTheme.openGreen, () => context.read<StationsProvider>().voteReport(stationId, report.id, true)),
                  const SizedBox(width: 14),
                  _VoteBtn(Icons.thumb_down_outlined, report.downvotes, AppTheme.closedRed, () => context.read<StationsProvider>().voteReport(stationId, report.id, false)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _tag(String label, Color color) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
        decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(6), border: Border.all(color: color.withOpacity(0.3))),
        child: Text(label, style: TextStyle(fontSize: 11, color: color, fontWeight: FontWeight.w600)),
      );

  String _fuelText(FuelType f) { switch (f) { case FuelType.regular: return '⛽ عادي'; case FuelType.premium: return '⭐ محسن'; case FuelType.both: return '⛽⭐ كلاهما'; default: return '❓ وقود'; } }
  String _crowdText(CrowdLevel c) { switch (c) { case CrowdLevel.none: return '🟢 لا طابور'; case CrowdLevel.low: return '🟡 قصير'; case CrowdLevel.medium: return '🟠 متوسط'; case CrowdLevel.high: return '🔴 طويل'; default: return '❓ ازدحام'; } }
}

class _VoteBtn extends StatelessWidget {
  final IconData icon; final int count; final Color color; final VoidCallback onTap;
  const _VoteBtn(this.icon, this.count, this.color, this.onTap);
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Row(children: [Icon(icon, size: 18, color: color), const SizedBox(width: 4), Text('$count', style: TextStyle(fontSize: 13, color: color, fontWeight: FontWeight.w600))]),
      );
}
