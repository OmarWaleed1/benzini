import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import '../models/station.dart';

class FirebaseService {
  static final FirebaseService _instance = FirebaseService._internal();
  factory FirebaseService() => _instance;
  FirebaseService._internal();

  final _db = FirebaseDatabase.instance;
  final _auth = FirebaseAuth.instance;
  final _messaging = FirebaseMessaging.instance;
  final _localNotif = FlutterLocalNotificationsPlugin();

  // ==================== AUTH ====================

  Future<UserCredential> signInWithPhone(String verificationId, String smsCode) async {
    final credential = PhoneAuthProvider.credential(
      verificationId: verificationId,
      smsCode: smsCode,
    );
    return await _auth.signInWithCredential(credential);
  }

  Future<void> verifyPhone({
    required String phoneNumber,
    required Function(String) onCodeSent,
    required Function(String) onError,
  }) async {
    await _auth.verifyPhoneNumber(
      phoneNumber: phoneNumber,
      verificationCompleted: (credential) async {
        await _auth.signInWithCredential(credential);
      },
      verificationFailed: (e) => onError(e.message ?? 'خطأ في التحقق'),
      codeSent: (verificationId, _) => onCodeSent(verificationId),
      codeAutoRetrievalTimeout: (_) {},
    );
  }

  Future<void> signOut() => _auth.signOut();

  User? get currentUser => _auth.currentUser;
  bool get isLoggedIn => _auth.currentUser != null;

  // ==================== USER PROFILE ====================

  Future<void> saveUser(AppUser user) async {
    await _db.ref('users/${user.uid}').set(user.toJson());
  }

  Future<AppUser?> getUser(String uid) async {
    final snap = await _db.ref('users/$uid').get();
    if (snap.exists && snap.value != null) {
      return AppUser.fromFirebase(snap.value as Map);
    }
    return null;
  }

  Future<void> addPoints(String uid, int points) async {
    final ref = _db.ref('users/$uid');
    final snap = await ref.get();
    if (snap.exists) {
      final user = AppUser.fromFirebase(snap.value as Map);
      user.points += points;
      user.reportsCount += 1;
      await ref.update({'points': user.points, 'reportsCount': user.reportsCount});
    }
  }

  // ==================== STATIONS ====================

  Stream<List<Station>> stationsStream() {
    return _db.ref('stations').onValue.map((event) {
      if (event.snapshot.value == null) return [];
      final map = event.snapshot.value as Map;
      return map.entries.map((e) => Station.fromFirebase(e.key, e.value as Map)).toList();
    });
  }

  Future<void> addStation(Station station) async {
    final ref = _db.ref('stations').push();
    final s = Station(
      id: ref.key!,
      name: station.name,
      address: station.address,
      city: station.city,
      lat: station.lat,
      lng: station.lng,
      addedBy: currentUser?.uid ?? '',
    );
    await ref.set(s.toJson());
  }

  // ==================== REPORTS ====================

  Stream<List<FuelReport>> reportsStream(String stationId) {
    return _db
        .ref('reports/$stationId')
        .orderByChild('reportedAt')
        .limitToLast(20)
        .onValue
        .map((event) {
      if (event.snapshot.value == null) return [];
      final map = event.snapshot.value as Map;
      final list = map.values
          .map((v) => FuelReport.fromFirebase(v as Map))
          .toList();
      list.sort((a, b) => b.reportedAt.compareTo(a.reportedAt));
      return list;
    });
  }

  Future<void> addReport(FuelReport report) async {
    await _db.ref('reports/${report.stationId}/${report.id}').set(report.toJson());
    // Notify subscribers
    await _notifySubscribers(report);
  }

  Future<void> voteReport(String stationId, String reportId, bool upvote) async {
    final ref = _db.ref('reports/$stationId/$reportId');
    final snap = await ref.get();
    if (snap.exists) {
      final report = FuelReport.fromFirebase(snap.value as Map);
      if (upvote) {
        await ref.update({'upvotes': report.upvotes + 1});
      } else {
        await ref.update({'downvotes': report.downvotes + 1});
      }
    }
  }

  // ==================== SUBSCRIPTIONS ====================

  Future<void> subscribeToStation(String userId, String stationId) async {
    await _db.ref('users/$userId/subscribedStations/$stationId').set(true);
    await _messaging.subscribeToTopic('station_$stationId');
  }

  Future<void> unsubscribeFromStation(String userId, String stationId) async {
    await _db.ref('users/$userId/subscribedStations/$stationId').remove();
    await _messaging.unsubscribeFromTopic('station_$stationId');
  }

  Future<bool> isSubscribed(String userId, String stationId) async {
    final snap = await _db.ref('users/$userId/subscribedStations/$stationId').get();
    return snap.exists;
  }

  Future<void> _notifySubscribers(FuelReport report) async {
    // In production: use Firebase Cloud Functions to send FCM
    // Here we trigger a local notification for demo
    if (report.status == StationStatus.open) {
      await _showLocalNotification(
        'محطة فُتحت! ⛽',
        'تم الإبلاغ عن فتح محطة قريبة منك',
      );
    }
  }

  // ==================== NOTIFICATIONS ====================

  Future<void> initNotifications() async {
    await _messaging.requestPermission();

    const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosSettings = DarwinInitializationSettings();
    await _localNotif.initialize(
      const InitializationSettings(android: androidSettings, iOS: iosSettings),
    );
  }

  Future<void> _showLocalNotification(String title, String body) async {
    const androidDetails = AndroidNotificationDetails(
      'benzini_channel', 'بنزيني',
      channelDescription: 'إشعارات محطات الوقود',
      importance: Importance.high,
      priority: Priority.high,
    );
    const details = NotificationDetails(
      android: androidDetails,
      iOS: DarwinNotificationDetails(),
    );
    await _localNotif.show(DateTime.now().millisecondsSinceEpoch ~/ 1000, title, body, details);
  }

  // ==================== LEADERBOARD ====================

  Future<List<AppUser>> getLeaderboard() async {
    final snap = await _db.ref('users').orderByChild('points').limitToLast(10).get();
    if (!snap.exists || snap.value == null) return [];
    final map = snap.value as Map;
    final users = map.values.map((v) => AppUser.fromFirebase(v as Map)).toList();
    users.sort((a, b) => b.points.compareTo(a.points));
    return users;
  }
}
