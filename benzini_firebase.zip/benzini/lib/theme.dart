import 'package:flutter/material.dart';

class AppTheme {
  // Deep petroleum green + warm amber — colors of Iraq's fuel world
  static const Color primary = Color(0xFF1A5C38);       // petroleum green
  static const Color primaryLight = Color(0xFF2E8B57);
  static const Color accent = Color(0xFFE8A020);         // amber/gold
  static const Color danger = Color(0xFFD32F2F);
  static const Color surface = Color(0xFFF8F6F1);        // warm off-white
  static const Color cardBg = Color(0xFFFFFFFF);
  static const Color textPrimary = Color(0xFF1A1A1A);
  static const Color textSecondary = Color(0xFF6B7280);
  static const Color divider = Color(0xFFE5E7EB);

  static const Color openGreen = Color(0xFF16A34A);
  static const Color closedRed = Color(0xFFDC2626);
  static const Color unknownGrey = Color(0xFF9CA3AF);

  static ThemeData get theme => ThemeData(
        useMaterial3: true,
        fontFamily: 'Cairo',
        colorScheme: ColorScheme.fromSeed(
          seedColor: primary,
          primary: primary,
          secondary: accent,
          surface: surface,
        ),
        scaffoldBackgroundColor: surface,
        appBarTheme: const AppBarTheme(
          backgroundColor: primary,
          foregroundColor: Colors.white,
          elevation: 0,
          centerTitle: true,
          titleTextStyle: TextStyle(
            fontFamily: 'Cairo',
            fontSize: 20,
            fontWeight: FontWeight.w700,
            color: Colors.white,
          ),
        ),
        cardTheme: CardTheme(
          color: cardBg,
          elevation: 2,
          shadowColor: Colors.black12,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: primary,
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 24),
            textStyle: const TextStyle(fontFamily: 'Cairo', fontSize: 16, fontWeight: FontWeight.w700),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: divider)),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: divider)),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: primary, width: 2)),
          labelStyle: const TextStyle(fontFamily: 'Cairo', color: textSecondary),
          hintStyle: const TextStyle(fontFamily: 'Cairo', color: textSecondary),
        ),
      );
}

// Helpers
Color crowdColor(crowdLevel) {
  switch (crowdLevel.toString()) {
    case 'CrowdLevel.none': return const Color(0xFF16A34A);
    case 'CrowdLevel.low': return const Color(0xFF65A30D);
    case 'CrowdLevel.medium': return const Color(0xFFD97706);
    case 'CrowdLevel.high': return const Color(0xFFDC2626);
    default: return AppTheme.unknownGrey;
  }
}
