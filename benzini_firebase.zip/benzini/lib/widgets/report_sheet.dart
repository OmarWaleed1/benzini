import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';
import '../models/station.dart';
import '../providers/stations_provider.dart';
import '../providers/auth_provider.dart';
import '../services/firebase_service.dart';
import '../theme.dart';

class ReportSheet extends StatefulWidget {
  final Station station;
  const ReportSheet({super.key, required this.station});
  @override
  State<ReportSheet> createState() => _ReportSheetState();
}

class _ReportSheetState extends State<ReportSheet> {
  StationStatus _status = StationStatus.open;
  FuelType _fuelType = FuelType.regular;
  CrowdLevel _crowdLevel = CrowdLevel.medium;
  double? _price;
  final _priceCtrl = TextEditingController();
  final _noteCtrl = TextEditingController();
  bool _submitting = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      padding: EdgeInsets.only(left: 20, right: 20, top: 20, bottom: MediaQuery.of(context).viewInsets.bottom + 24),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Center(child: Container(width: 48, height: 5, decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(3)))),
            const SizedBox(height: 16),
            Row(children: [
              Expanded(child: Text('تقرير - ${widget.station.name}', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700, color: AppTheme.textPrimary))),
              Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4), decoration: BoxDecoration(color: AppTheme.accent.withOpacity(0.15), borderRadius: BorderRadius.circular(12)),
                  child: const Text('+10 نقاط', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppTheme.accent))),
            ]),
            const SizedBox(height: 20),

            _Label('حالة المحطة'),
            const SizedBox(height: 8),
            Row(children: [
              _Chip('✅ مفتوحة', _status == StationStatus.open, () => setState(() => _status = StationStatus.open), AppTheme.openGreen),
              const SizedBox(width: 8),
              _Chip('🔴 مغلقة', _status == StationStatus.closed, () => setState(() => _status = StationStatus.closed), AppTheme.closedRed),
            ]),
            const SizedBox(height: 18),

            _Label('نوع الوقود'),
            const SizedBox(height: 8),
            Wrap(spacing: 8, runSpacing: 8, children: [
              _Chip('⛽ عادي', _fuelType == FuelType.regular, () => setState(() => _fuelType = FuelType.regular), AppTheme.primary),
              _Chip('⭐ محسن', _fuelType == FuelType.premium, () => setState(() => _fuelType = FuelType.premium), AppTheme.accent),
              _Chip('✅ كلاهما', _fuelType == FuelType.both, () => setState(() => _fuelType = FuelType.both), Colors.teal),
              _Chip('❌ لا يوجد', _fuelType == FuelType.unknown, () => setState(() => _fuelType = FuelType.unknown), Colors.grey),
            ]),
            const SizedBox(height: 18),

            _Label('مستوى الازدحام'),
            const SizedBox(height: 8),
            Wrap(spacing: 8, runSpacing: 8, children: [
              _Chip('🟢 لا يوجد', _crowdLevel == CrowdLevel.none, () => setState(() => _crowdLevel = CrowdLevel.none), AppTheme.openGreen),
              _Chip('🟡 قصير', _crowdLevel == CrowdLevel.low, () => setState(() => _crowdLevel = CrowdLevel.low), Colors.amber),
              _Chip('🟠 متوسط', _crowdLevel == CrowdLevel.medium, () => setState(() => _crowdLevel = CrowdLevel.medium), Colors.orange),
              _Chip('🔴 طويل جداً', _crowdLevel == CrowdLevel.high, () => setState(() => _crowdLevel = CrowdLevel.high), AppTheme.closedRed),
            ]),
            const SizedBox(height: 18),

            _Label('السعر (دينار عراقي) - اختياري'),
            const SizedBox(height: 8),
            TextField(controller: _priceCtrl, keyboardType: TextInputType.number, textAlign: TextAlign.right,
                decoration: const InputDecoration(hintText: 'مثال: 750', suffixText: 'د.ع'), onChanged: (v) => _price = double.tryParse(v)),
            const SizedBox(height: 18),

            _Label('ملاحظة (اختياري)'),
            const SizedBox(height: 8),
            TextField(controller: _noteCtrl, textAlign: TextAlign.right, maxLines: 2, decoration: const InputDecoration(hintText: 'أي معلومة إضافية تفيد الناس...')),
            const SizedBox(height: 24),

            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _submitting ? null : _submit,
                child: _submitting
                    ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                    : const Text('إرسال التقرير'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _submit() async {
    setState(() => _submitting = true);
    final auth = context.read<AppAuthProvider>();
    final report = FuelReport(
      id: const Uuid().v4(),
      stationId: widget.station.id,
      userId: auth.user?.uid ?? 'guest',
      userDisplayName: auth.user?.displayName ?? 'مجهول',
      fuelType: _fuelType,
      crowdLevel: _crowdLevel,
      status: _status,
      price: _price,
      note: _noteCtrl.text.trim().isEmpty ? null : _noteCtrl.text.trim(),
      reportedAt: DateTime.now(),
    );
    await context.read<StationsProvider>().addReport(report);
    // Add points
    if (auth.isLoggedIn) {
      await FirebaseService().addPoints(auth.user!.uid, 10);
      await auth.refreshUser();
    }
    if (mounted) {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('شكراً! تم إرسال تقريرك ✅ +10 نقاط'),
        backgroundColor: AppTheme.openGreen,
        behavior: SnackBarBehavior.floating,
      ));
    }
  }
}

class _Label extends StatelessWidget {
  final String t;
  const _Label(this.t);
  @override Widget build(BuildContext context) => Text(t, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppTheme.textPrimary));
}

class _Chip extends StatelessWidget {
  final String label; final bool selected; final VoidCallback onTap; final Color color;
  const _Chip(this.label, this.selected, this.onTap, this.color);
  @override Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: AnimatedContainer(
      duration: const Duration(milliseconds: 150),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(color: selected ? color : Colors.white, borderRadius: BorderRadius.circular(20), border: Border.all(color: selected ? color : AppTheme.divider, width: selected ? 2 : 1)),
      child: Text(label, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: selected ? Colors.white : AppTheme.textSecondary)),
    ),
  );
}
