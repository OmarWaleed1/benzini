import 'package:flutter/material.dart';
import 'package:timeago/timeago.dart' as timeago;
import '../models/station.dart';
import '../theme.dart';

class StationCard extends StatelessWidget {
  final Station station;
  final double? distanceKm;
  final VoidCallback onTap;

  const StationCard({super.key, required this.station, this.distanceKm, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final report = station.latestReport;
    final status = station.currentStatus;

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  // Status indicator
                  Container(
                    width: 12,
                    height: 12,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: status == StationStatus.open
                          ? AppTheme.openGreen
                          : status == StationStatus.closed
                              ? AppTheme.closedRed
                              : AppTheme.unknownGrey,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      station.name,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                        color: AppTheme.textPrimary,
                      ),
                    ),
                  ),
                  if (distanceKm != null)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: AppTheme.primary.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        '${distanceKm!.toStringAsFixed(1)} كم',
                        style: const TextStyle(
                          fontSize: 12,
                          color: AppTheme.primary,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 4),
              Text(
                station.address,
                style: const TextStyle(fontSize: 13, color: AppTheme.textSecondary),
              ),
              if (report != null) ...[
                const SizedBox(height: 12),
                const Divider(height: 1, color: AppTheme.divider),
                const SizedBox(height: 12),
                Row(
                  children: [
                    _Badge(label: _statusText(status), color: status == StationStatus.open ? AppTheme.openGreen : status == StationStatus.closed ? AppTheme.closedRed : AppTheme.unknownGrey),
                    const SizedBox(width: 8),
                    _Badge(label: _fuelText(station.currentFuelType), color: AppTheme.primary),
                    const SizedBox(width: 8),
                    _Badge(label: _crowdText(station.currentCrowdLevel), color: crowdColor(station.currentCrowdLevel)),
                    const Spacer(),
                    if (report.price != null)
                      Text(
                        '${report.price!.toInt()} د.ع',
                        style: const TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          color: AppTheme.accent,
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    const Icon(Icons.access_time, size: 13, color: AppTheme.textSecondary),
                    const SizedBox(width: 4),
                    Text(
                      timeago.format(report.reportedAt, locale: 'ar'),
                      style: const TextStyle(fontSize: 12, color: AppTheme.textSecondary),
                    ),
                    const SizedBox(width: 12),
                    const Icon(Icons.thumb_up_outlined, size: 13, color: AppTheme.textSecondary),
                    const SizedBox(width: 4),
                    Text('${report.upvotes}', style: const TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
                  ],
                ),
              ] else ...[
                const SizedBox(height: 8),
                const Text('لا توجد تقارير بعد', style: TextStyle(fontSize: 13, color: AppTheme.textSecondary)),
              ],
            ],
          ),
        ),
      ),
    );
  }

  String _statusText(StationStatus s) {
    switch (s) {
      case StationStatus.open: return '✅ مفتوحة';
      case StationStatus.closed: return '🔴 مغلقة';
      default: return '❓ غير معروف';
    }
  }

  String _fuelText(FuelType f) {
    switch (f) {
      case FuelType.regular: return '⛽ عادي';
      case FuelType.premium: return '⭐ محسن';
      case FuelType.both: return '⛽ عادي + محسن';
      default: return '❓ نوع الوقود';
    }
  }

  String _crowdText(CrowdLevel c) {
    switch (c) {
      case CrowdLevel.none: return '🟢 لا يوجد طابور';
      case CrowdLevel.low: return '🟡 طابور قصير';
      case CrowdLevel.medium: return '🟠 طابور متوسط';
      case CrowdLevel.high: return '🔴 طابور طويل';
      default: return '❓ الازدحام';
    }
  }
}

class _Badge extends StatelessWidget {
  final String label;
  final Color color;
  const _Badge({required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Text(label, style: TextStyle(fontSize: 11, color: color, fontWeight: FontWeight.w600)),
    );
  }
}
